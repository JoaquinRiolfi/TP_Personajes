class PeliculaSerie{
    id;
    imagen;
    titulo;
    fechaCreacion;
    calificacion;
}
export default PeliculaSerie;