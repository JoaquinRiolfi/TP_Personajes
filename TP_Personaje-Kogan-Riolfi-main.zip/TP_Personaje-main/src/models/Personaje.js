class Personaje{
    id;
    imagen;
    nombre;
    edad;
    peso;
    historia;
}
export default Personaje;